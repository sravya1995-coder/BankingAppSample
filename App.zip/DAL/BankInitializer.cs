﻿using BankingAppSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BankingAppSample.DAL
{
    
        public class BankInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<BankContext>
        {
            protected override void Seed(BankContext context)
            {
                var users = new List<User>
            {
            new User{UserID=1234,Email="sravya@gmail.com",Password="abcde"},
            new User{UserID=5678,Email="harsha@gmail.com",Password="ab1cde"},
            new User{UserID=9012,Email="tarak@gmail.com",Password="abcd2e"},

            };

                users.ForEach(s => context.Users.Add(s));
                context.SaveChanges();
                var transactions = new List<Transaction>
            {
            new Transaction{TransactionID=1,TransactionDate=DateTime.Parse("2005-09-01"),Amount=5000,Reason="Shopping"},
            new Transaction{TransactionID=2,TransactionDate=DateTime.Parse("2015-09-01"),Amount=6000,Reason="Rent"},
            new Transaction{TransactionID=3,TransactionDate=DateTime.Parse("2015-09-11"),Amount=5000,Reason="Bills"},
            new Transaction{TransactionID=4,TransactionDate=DateTime.Parse("2014-09-01"),Amount=6000,Reason="Loan"},

            };
                transactions.ForEach(s => context.Transactions.Add(s));
                context.SaveChanges();

            }
        }
    }
