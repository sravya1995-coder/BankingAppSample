﻿using System;
using System.ComponentModel.DataAnnotations;

using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.ComponentModel;

namespace BankingAppSample.Models
{
    public class Transaction
    {
        [Key]
        [Required]
        public int TransactionID { get; set; }


        [Required]
        public DateTime TransactionDate { get; set; }
        public decimal Amount { get; set; }

        public string Reason { get; set; }


    }
}