﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankingApp.Web.Controllers;
using System;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp.Web.Controllers.Tests
{
    [TestClass()]
    public class LoginTests
    {
        [TestMethod()]
        public void LoginTest()
        {
            // Arrange
            LoginController controller = new LoginController();

            // Act
            ViewResult result = controller.Login() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
    }
}