﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankingApp.Web.Controllers;
using System.Web.Mvc;
using BankingApp.Entity;
namespace BankingApp.Web.Tests.Controllers
{
    [TestClass]
    public class TransactionTest
    {
        [TestMethod]
        public void TransactionDetails()
        {
            // Arrange
            TransactionsController controller = new TransactionsController();

            // Act
            ViewResult result = controller.Details(2) as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TransactionEdit()
        {
            // Arrange
            TransactionsController controlle = new TransactionsController();

            // Act
            ViewResult result = controlle.Edit(1) as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
