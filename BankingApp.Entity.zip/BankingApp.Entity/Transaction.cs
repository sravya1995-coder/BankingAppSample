﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BankingApp.Entity
{
    public class Transaction
    {
        [Key]
        [Required]
        public int TransactionID { get; set; }


        [Required]
        public DateTime TransactionDate { get; set; }
        public decimal Amount { get; set; }

        public string Reason { get; set; }
    
}
}