﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BankingApp.Entity;
using BankingApp.DAL;

namespace BankingApp.Web.Controllers
{
    public class LoginController : Controller
    {
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User objUser)
        {
            if (ModelState.IsValid)
            {
                using (BankContext db = new BankContext())
                {
                    var obj = db.Users.Where(a => a.Email.Equals(objUser.Email) && a.Password.Equals(objUser.Password)).FirstOrDefault();
                    if (obj != null)
                    {
                        return RedirectToAction("UserDashBoard");
                    }
                    else
                    {
                        return RedirectToAction("ErrorLogin");
                    }
                }
            }
            return View(objUser);
        }

        public ActionResult UserDashBoard()
        {

            return View();

        }


        public ActionResult ErrorLogin()
        {
            return View();
        }
    }
}